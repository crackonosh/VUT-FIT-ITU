﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace GraphingTracker
{
    public partial class ManageRecords : ContentPage
    {
        public ManageRecords()
        {
            InitializeComponent();
        }
    }
}
