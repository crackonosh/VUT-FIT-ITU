﻿using System;
using System.Collections.Generic;
using GraphingTracker.Pages;
using Xamarin.Forms;


namespace GraphingTracker
{
    public partial class AddItem : ContentPage
    {
        public AddItem()
        {
            InitializeComponent();
        }

      
    }
}
