﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace GraphingTracker
{
    public partial class AboutAppPage : ContentPage
    {
        public AboutAppPage()
        {
            InitializeComponent();
        }
    }
}
